INSERT INTO LPECOM_REALISATEURS VALUES
(16, "Scott", "Ridley", 0, "uk", "1937-11-30"),
(22, "Aronofsky", "Darren", 0, "us", "1969-02-12"),
(47, "Jenkins", "Patty", 1, "us", "1971-07-24"),
(66, "Ritchie", "Guy", 0, "uk", "1968-09-10");


INSERT INtO LPECOM_FILMS VALUES 
(121, "Requiem for a Dream", 22, "2000-10-27"),
(546, "Gladiator", 16, "2000-05-05"),
-- (666, "Fight Club", 61, "1999-10-15"),
(775, "Blade Runner", 16, "1982-06-25"),
(984, "Seul sur Mars", 16, "2015-10-02"),
(986, "Black Swan", 22, "2010-12-03"),
(987, "Wonder Woman", 47, "2017-06-02");
-- (988, "The Tomorrow Man", 85, "2019-05-22");

INSERT INTO LPECOM_FILMS_NOTES VALUES
(1, 546, 4.5),
(2, 546, 2.5),
(3, 775, 5.0),
(4, 984, 3.5),
(5, 987, 3.1),
-- (6, 666, 4.2),
(7, 986, 3.0),
(8, 986, 4.3),
(9, 121, 1.0);
