import os

for i in range(1, 7):
    print(f'\n\nExercice {i}:\n')
    os.system(f'python ex{i}.py')
    input("\nClicker sur enter pour continuer...")