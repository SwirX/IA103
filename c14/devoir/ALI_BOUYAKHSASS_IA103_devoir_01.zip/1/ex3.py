for i in range(5, 0, -1):
    print("*"*i)
