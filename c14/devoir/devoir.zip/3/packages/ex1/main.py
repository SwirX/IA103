from ecole.eleve import Eleve
from ecole.professeur import Professeur

e1 = Eleve('Taha', '3e annee')
p1 = Professeur('M. Abderrahman', 'Machine Learning')
e1.afficher_infos()
p1.afficher_infos()
